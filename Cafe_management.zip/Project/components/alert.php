<?php
if (!empty($success_msg)) 
{
    foreach ($success_msg as $msg) 
    {
        echo "<script>swal('Success!', '$msg', 'success');</script>";
    }
}
if (!empty($warning_msg)) 
{
    echo "<script>swal('Notice', '$warning_msg', 'warning');</script>";
}
    if(isset($info_msg))
    {
        foreach($info_msg as $info_msg)
        {
            echo '<script>swal("'.$info_msg.'","success");</script>';
        }
    }
    if(isset($error_msg))
    {
        foreach($error_msg as $error_msg)
        {
            echo '<script>swal("'.$error_msg.'","success");</script>';
        }
    }


?>