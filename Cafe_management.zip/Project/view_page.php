<?php
include 'components/connection.php';
session_start();

// Set user_id if logged in
$user_id = $_SESSION['user_id'] ?? '';

// Logout handler
if (isset($_POST['logout'])) {
    session_destroy();
    header("location:login.php");
    exit;
}

// Message arrays
$success_msg = [];
$warning_msg = '';

// Add to wishlist
if (isset($_POST['add_to_wishlist'])) {
    $id = uniqid('wish_');
    $product_id = filter_var($_POST['product_id'], FILTER_SANITIZE_STRING);

    $verify_wishlist = $conn->prepare("SELECT * FROM wishlist WHERE user_id = ? AND product_id = ?");
    $verify_wishlist->execute([$user_id, $product_id]);

    $cart_num = $conn->prepare("SELECT * FROM cart WHERE user_id = ? AND product_id = ?");
    $cart_num->execute([$user_id, $product_id]);

    if ($verify_wishlist->rowCount() > 0) {
        $warning_msg = 'Product already exists in your wishlist.';
    } elseif ($cart_num->rowCount() > 0) {
        $warning_msg = 'Product already exists in your cart.';
    } else {
        $select_price = $conn->prepare("SELECT * FROM products WHERE id = ? LIMIT 1");
        $select_price->execute([$product_id]);
        $fetch_price = $select_price->fetch(PDO::FETCH_ASSOC);

        $insert_wishlist = $conn->prepare("INSERT INTO wishlist (id, user_id, product_id, price) VALUES (?, ?, ?, ?)");
        $insert_wishlist->execute([$id, $user_id, $product_id, $fetch_price['price']]);

        $success_msg[] = 'Product added to wishlist successfully.';
    }
}

// Add to cart
if (isset($_POST['add_to_cart'])) {
    $id = uniqid('cart_');
    $product_id = filter_var($_POST['product_id'], FILTER_SANITIZE_STRING);
    $qty = filter_var($_POST['qty'], FILTER_SANITIZE_STRING);

    $verify_cart = $conn->prepare("SELECT * FROM cart WHERE user_id = ? AND product_id = ?");
    $verify_cart->execute([$user_id, $product_id]);

    $max_cart_items = $conn->prepare("SELECT * FROM cart WHERE user_id = ?");
    $max_cart_items->execute([$user_id]);

    if ($verify_cart->rowCount() > 0) {
        $warning_msg = 'Product already exists in your cart.';
    } elseif ($max_cart_items->rowCount() >= 20) {
        $warning_msg = 'Cart is full.';
    } else {
        $select_price = $conn->prepare("SELECT * FROM products WHERE id = ? LIMIT 1");
        $select_price->execute([$product_id]);
        $fetch_price = $select_price->fetch(PDO::FETCH_ASSOC);

        $insert_cart = $conn->prepare("INSERT INTO cart (id, user_id, product_id, price, qty) VALUES (?, ?, ?, ?, ?)");
        $insert_cart->execute([$id, $user_id, $product_id, $fetch_price['price'], $qty]);

        $success_msg[] = 'Product added to cart successfully.';
    }
}
?>
<style type="text/css">
    <?php include 'style.css'; ?>
</style>

<html>
<head>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>Cafe-product detail page</title>
</head>
<body>
    <?php include 'components/header.php'; ?>

    <div class="main">
        <div class="banner">
            <h1>product detail</h1>
        </div>

        <div class="title2">
            <a href="home.php">Home</a><span> / product detail</span>
        </div>

        <section class="view_page">
            <?php
            if(isset($_GET['pid'])){
                $pid=$_GET['pid'];
                $select_products =$conn-> prepare("SELECT * FROM products where id='$pid '");
                $select_products -> execute();
                if($select_products-> rowCount()>0){
                    while($fetch_products = $select_products->fetch(PDO::FETCH_ASSOC)){

            ?>  
            <form action="" method="post">
                <img src="image/<?php echo $fetch_products['image']; ?>" >
                <div class="detail">
                    <div class="price">Rs.<?php echo $fetch_products['price']; ?>/-</div>
                    <div class="name"><?php echo $fetch_products['name']; ?></div>
                    <div class="detail">
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloremque tenetur amet explicabo eos nobis minus cupiditate, consequuntur atque voluptas? Quam sit mollitia error numquam debitis unde laborum assumenda rem quibusdam!</p>

                    </div>
                    <input type="hidden" name="product_id" value="<?php echo $fetch_products['id']; ?>">
                    <div class="button">
                        <button type="submit" name="add_to_wishlist" class="btn">
                            add to wishlist <i class="bx bx-heart"></i>
                        </button>
                    <input type="hidden" name="qty" value="1" min="0" class="quantity">
                        <button type="submit" name="add_to_cart" class="btn">
                            add to cart <i class="bx bx-cart"></i>
                        </button>
                    </div>
                </div>
            </form>
            <?php 
            
                    }
                }
            }
            ?>
        </section>

        <?php include 'components/footer.php'; ?>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
    <script src="script.js"></script>
    <?php include 'components/alert.php'; ?>
</body>
</html>