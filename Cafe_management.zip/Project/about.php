<?php
include 'components/connection.php';
session_start();
if(isset($_SESSION['user_id'])){
    $user_id = $_SESSION['user_id'];
}else{
    $user_id='';
}
if(isset($_POST['logout']))
{
    session_destroy();
    header("location: login.php");
    
}
?>
<style type="text/CSS">
    <?php  include 'style.css';?>
</style>

<html>
    <head>
        <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
        <title>Cafe-about us page</title>
    </head>
    <body>
        <?php  include 'components/header.php';?>
        <div class="main">

            <div class="banner">
                <h1>about us</h1>
            </div>
            <div class="title">
                <a href="home.php">home</a><span>about</span>
            </div>
            <div class="about-category">
                <div class="box">
                    <img src="img/espresso.jpg" width=500 height=300>
                    <div class="detail">
                        <span>coffee</span>
                        <h1>espresso</h1>
                        <a href="view_products.php" class="btn">shop now</a>
                    </div>
                </div>
                <div class="box">
                    <img src="img/Frappe.jpg" width=500 height=300>
                    <div class="detail">
                        <span>coffee</span>
                        <h1>frappe</h1>
                        <a href="view_products.php" class="btn">shop now</a>
                    </div>
                </div>
                <div class="box">
                    <img src="img/Flat white.jpg"width=500 height=300>
                    <div class="detail">
                        <span>coffee</span>
                        <h1>flat white</h1>
                        <a href="view_products.php" class="btn">shop now</a>
                    </div>
                </div>
                <div class="box">
                    <img src="img/Mocha.jpg" width=500 height=300>
                    <div class="detail">
                        <span>coffee</span>
                        <h1>mocha</h1>
                        <a href="view_products.php" class="btn">shop now</a>
                    </div>
                </div>
            </div>
            <section class="services">
                <div class="title">
                    <img src="img/logo2.png" class="logo" >
                    <h1>why choose us</h1>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quidem, labore.</p>
                </div>
                <div class="box-container">
                    <div class="box">
                        <img src="img/icon1.png" >
                        <div class="details">
                            <h3>great savings</h3>
                            <p>save big every order</p>
                        </div>
                    </div>
                    <div class="box">
                        <img src="img/icon2.png" >
                        <div class="details">
                            <h3>24*7 support</h3>
                            <p>one-on-one support</p>
                        </div>
                    </div>
                    <div class="box">
                        <img src="img/icon3.png" >
                        <div class="details">
                            <h3>gift vouchar</h3>
                            <p>vouchars on every festivals</p>
                        </div>
                    </div>
                    <div class="box">
                        <img src="img/icon4.png" >
                        <div class="details">
                            <h3>worldwide delivery</h3>
                            <p>dropship worlswide</p>
                        </div>
                    </div>
                </div>
             </section>
             <div class="about">
                <div class="row">
                    <div class="img_box">
                        <img src="img/quote.png" alt="">
                    </div>
                    <div class="detail">
                        <h1>Visit our beautiful cafe</h1>
                        <p>Our cafe is a cozy and inviting space that offers a relaxing atmosphere for customers to enjoy delicious coffee, tea, and light refreshments. We focus on providing a welcoming environment with comfortable seating, free Wi-Fi, and a curated playlist to enhance the overall experience. Our menu features a selection of high-quality coffee and tea options, along with tasty snacks and pastries, perfect for a quick bite or a leisurely afternoon. The staff is known for their friendly and attentive service, creating a sense of community and making everyone feel at home.</p>
                        <a href="view_products.php" class="btn">shop now</a>
                    </div>
                </div>
             </div>
             <div class="testimonal-container">
    <div class="title">
        <img src="img/logo2.png" class="logo">
        <h1>what people say about us</h1>
       
    </div>

    <div class="container">
        <div class="testimonal-item active">
            <img src="img/pic3.jpg" width="170" height="200">
            <h1>Jiya </h1>
            <p>Loved the clean layout and quick checkout process. Menu images look great, and delivery was on time. Highly recommend this site .</p>
        </div>
        <div class="testimonal-item">
            <img src="img/pic2.jpg">
            <h1>John Doe</h1>
            <p>Excellent experience.</p>
        </div>
        <div class="testimonal-item">
            <img src="img/pic3.jpg">
            <h1>Jane Doe</h1>
            <p>Very satisfied with the service.</p>
        </div>

        <!-- Corrected buttons -->
        <div class="left-arrow" onclick="prevSlide()"><i class="bx bxs-left-arrow-alt"></i></div>
        <div class="right-arrow" onclick="nextSlides()"><i class="bx bxs-right-arrow-alt"></i></div>
    </div>
</div>

             <?php  include 'components/footer.php';?>
        </div>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
        <script src="script.js"></script>
        <?php  include 'components/alert.php';?>
    </body>
</html>