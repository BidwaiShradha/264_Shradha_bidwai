
<?php
include 'components/connection.php';
session_start();
if(isset($_SESSION['user_id'])){
    $user_id = $_SESSION['user_id'];
}else{
    $user_id='';
}
if(isset($_POST['logout']))
{
    session_destroy();
    header("location: login.php");
    
}
?>
<style type="text/CSS">
    <?php  include 'style.css';?>
</style>

<html>
    <head>
        <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
        <title>Cafe-home page</title>
    </head>
    <body>
        <?php  include 'components/header.php';?>
        <div class="main">

            <section class="home-section">
            <div class="slider">
                <div class="slider_slider slide1">
                    <div class="overlay"> </div>
                    <div class="slide-detail">
                        <h1>Lorem ipsum dolar</h1>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem odit ut sapiente facere veritatis in fuga possimus aliquid quis soluta totam expedita harum porro explicabo, molestias esse dignissimos perferendis inventore.</p>
                        <a href="view_products.php" class="btn">shop now</a>
                    </div>
                    <div class="hero-dec-top"></div>
                    <div class="hero-dec-bottom"></div>

                </div>
                <!-- slide end -->
                 <div class="slider_slider slide2">
                    <div class="overlay"> </div>
                    <div class="slide-detail">
                        <h1>Welcome to my shop</h1>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem odit ut sapiente facere veritatis in fuga possimus aliquid quis soluta totam expedita harum porro explicabo, molestias esse dignissimos perferendis inventore.</p>
                        <a href="view_products.php" class="btn">shop now</a>
                    </div>
                    <div class="hero-dec-top"></div>
                    <div class="hero-dec-bottom"></div>

                </div>
                <!-- slide end -->
                <div class="slider_slider slide3">
                    <div class="overlay"> </div>
                    <div class="slide-detail">
                        <h1>Lorem ipsum dolar</h1>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem odit ut sapiente facere veritatis in fuga possimus aliquid quis soluta totam expedita harum porro explicabo, molestias esse dignissimos perferendis inventore.</p>
                        <a href="view_products.php" class="btn">shop now</a>
                    </div>
                    <div class="hero-dec-top"></div>
                    <div class="hero-dec-bottom"></div>

                </div>
                <!-- slide end -->
                <div class="slider_slider slide4">
                    <div class="overlay"> </div>
                    <div class="slide-detail">
                        <h1>Lorem ipsum dolar</h1>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem odit ut sapiente facere veritatis in fuga possimus aliquid quis soluta totam expedita harum porro explicabo, molestias esse dignissimos perferendis inventore.</p>
                        <a href="view_products.php" class="btn">shop now</a>
                    </div>
                    <div class="hero-dec-top"></div>
                    <div class="hero-dec-bottom"></div>

                </div>
                <!-- slide end -->
                <div class="slider_slider slide5">
                    <div class="overlay"> </div>
                    <div class="slide-detail">
                        <h1>Lorem ipsum dolar</h1>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem odit ut sapiente facere veritatis in fuga possimus aliquid quis soluta totam expedita harum porro explicabo, molestias esse dignissimos perferendis inventore.</p>
                        <a href="view_products.php" class="btn">shop now</a>
                    </div>
                    <div class="hero-dec-top"></div>
                    <div class="hero-dec-bottom"></div>

                </div>
                <!-- slide end -->
                <div class="left-arrow">
                    <i class="bxs-left-arrow"></i>
                </div>
                <div class="right-arrow">
                    <i class="bxs-left-arrow"></i>
                </div>

            </div>

            </section>
            
            <!-- home slider end -->
             <section class="thumb">
                <div class="box-container">
                    <div class="box">
                        <img src="img/p5.jpg" width="150" height="150" >
                        <h3>coffee</h3>
                        <p>A warm hug in a mug, brewing dreams and chasing away the blues</p>
                        <i class="bx bx-chevro-right"></i>
                    </div>

                    <div class="box">
                        <img src="img/p2.jpg" width="150" height="150" >
                        <h3>juices</h3>
                        <p>A symphony of sunshine in every glass,bottled freshness that dances on the tongue </p><i class="bx bx-chevro-right"></i>
                    </div>
                    <div class="box">
                        <img src="img/p3.jpg" width="150" height="150">
                        <h3>icecream</h3>
                        <p>A day without icecream is like a day without sunshine </p><i class="bx bx-chevro-right"></i>
                    </div>
                    <div class="box">
                        <img src="img/p4.jpg" width="150" height="150" >
                        <h3>Donut</h3>
                        <p>Asmall circle of pure joy, sprinkled with happiness and a touch of deliciouness</p><i class="bx bx-chevro-right"></i>
                    </div>



                </div>

             </section>
             <section class="container">
                <div class="box-container">
                    <div class="box">
                        <img src="img/about.jpg" >
                    </div>
                    <div class="box">
                        <img src="img/logo2.png" >
                        <span>healthy coffee</span>
                        <h1>save up to 50% off</h1>
                        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos accusantium maiores adipisci odit quo error vitae voluptatum minima. Maxime, veritatis.</p>

                    </div>
                </div>
             </section>
             <section class="shop">
                <div class="title">
                    <img src="img/logo2.png" width=60>
                    <h1>Trending product</h1>
                </div>
                <div class="row">
                    <img src="img/mocha.jpg" width=490 >
                    <div class="row-details">
                        <img src="img/latte.jpg" width= 690>
                        <div class="top-footer">
                            <h1>a cup of Coffee makes you healthy</h1>
                        </div>
                    </div>
                </div>
                <div class="box-container">
                    <div class="box">
                        <img src="img/product2.png">
                        <a href="view_products.php" class="btn"> show now</a>
                    </div>
                    <div class="box">
                        <img src="img/product1.jpg">
                        <a href="view_products.php" class="btn"> show now</a>
                    </div>
                    <div class="box">
                        <img src="img/product3.jpg">
                        <a href="view_products.php" class="btn"> show now</a>
                    </div>
                    <div class="box">
                        <img src="img/pic1.jpg">
                        <a href="view_products.php" class="btn"> show now</a>
                    </div>
                    <div class="box">
                        <img src="img/pic2.jpg">
                        <a href="view_products.php" class="btn"> show now</a>
                    </div>
                </div>
             </section>
             <section class="shop-category">
                <div class="box-container">
                    <div class="box">
                        <img src="img/Ristretto.jpg" width=620  height=500>
                        <div class="detail">
                            <span>BIG OFFERS</span>
                            <h1>Extra 15% off</h1>
                            <a href="view_products.php" class="btn">shop now</a>
                        </div>
                    </div>
                    <div class="box">
                        <img src="img/Macchiato.jpg" width=620 height=500>
                        <div class="detail">
                            <span>new in taste</span>
                            <h1>Coffee house</h1>
                            <a href="view_products.php" class="btn">shop now</a>
                        </div>
                    </div>
                </div>
             </section>
             <section class="services">
                <div class="box-container">
                    <div class="box">
                        <img src="img/icon2.png" >
                        <div class="details">
                            <h3>great savings</h3>
                            <p>save big every order</p>
                        </div>
                    </div>
                    <div class="box">
                        <img src="img/icon1.png" >
                        <div class="details">
                            <h3>24*7 support</h3>
                            <p>one-on-one support</p>
                        </div>
                    </div>
                    <div class="box">
                        <img src="img/icon0.png" >
                        <div class="details">
                            <h3>gift vouchar</h3>
                            <p>vouchars on every festivals</p>
                        </div>
                    </div>
                    <div class="box">
                        <img src="img/icon.png" >
                        <div class="details">
                            <h3>worldwide delivery</h3>
                            <p>dropship worlswide</p>
                        </div>
                    </div>
                </div>
             </section>
             <section class="brand">
                <div class="box-container">
                    <div class="box">
                        <img src="img/Affogato.jpg" alt=""  width=300>
                    </div>
                    <div class="box">
                        <img src="img/Affogato.jpg" alt="" width=300>
                    </div>
                    <div class="box">
                        <img src="img/Affogato.jpg" alt=""  width=300>
                    </div>
                    <div class="box">
                        <img src="img/Affogato.jpg" alt=""  width=300>
                    </div>
                    <div class="box">
                        <img src="img/Affogato.jpg" alt=""  width=300>
                    </div>
                </div>
             </section>

             <?php  include 'components/footer.php';?>
        </div>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
        <script src="script.js"></script>
        <?php  include 'components/alert.php';?>
    </body>
</html>